<?php 

/**
* 
*/
class Mtemplating extends CI_Model
{
	#Start Function Untuk sidebar bank soal#
	// public function get_tingkat()
	// {
	// 	$this->db->where('status','1');
	// 	$this->db->select('id,aliasTingkat');
	// 	$this->db->from('tb_tingkat');
	// 	$query = $this->db->get();
 //        return $query->result_array();
	// }
	#END Function untuk sidebar bank soal#
}

?>