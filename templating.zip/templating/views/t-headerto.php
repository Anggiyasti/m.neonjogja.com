<html class="frontend">



    <!-- START Head -->

    <head>

        <title>Tryout Online</title>

        <link rel="stylesheet" href="<?= base_url('assets/plugins/magnific/css/magnific-popup.min.css'); ?>">

        <link rel="stylesheet" href="<?= base_url('assets/plugins/owl/css/owl.carousel.min.css'); ?>">



        <link rel="shortcut icon" href="<?= base_url('assets/back/img/favicon.png') ?>">

        <link rel="stylesheet" href="<?= base_url('assets/library/bootstrap/css/bootstrap.min.css'); ?>">

        <link rel="stylesheet" href="<?= base_url('assets/stylesheet/layout.css'); ?>">

        <link rel="stylesheet" href="<?= base_url('assets/stylesheet/uielement.css'); ?>">



        <link rel="stylesheet" href="<?= base_url('assets/plugins/selectize/css/selectize.min.css'); ?>">

        <script src="<?= base_url('assets/sal/sweetalert-dev.js');?>"></script>
        <link rel="stylesheet" href="<?= base_url('assets/sal/sweetalert.css');?>">
        <!--<link rel="stylesheet" href="../plugins/datatables/css/jquery.datatables.min.css">-->

        <!--/ Plugins stylesheet -->

        <!-- Application stylesheet : mandatory -->

        <!--/ Application stylesheet -->



<!--

        <link href="<?php echo base_url(); ?>assets/css/demo.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>assets/css/soal.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>assets/css/soal2.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>assets/css/sweetalert.css" rel="stylesheet" />-->



        <!-- END STYLESHEETS -->



        <!-- START JAVASCRIPT SECTION - Load only modernizr script here -->

        <script src="<?= base_url('assets/library/modernizr/js/modernizr.min.js'); ?>"></script>

        <script type="text/javascript" src="<?= base_url('assets/library/jquery/js/jquery.min.js') ?>"></script>



        <link rel="stylesheet" href="<?= base_url('assets/plugins/layerslider/css/layerslider.min.css'); ?>">

    </head>

    <body bg="black">



<!--          CSS for Demo Purpose, don't include it in your project     

        <link href="<?php echo base_url(); ?>assets/peserta/css/demo.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>assets/peserta/css/soal.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>assets/peserta/css/soal2.css" rel="stylesheet" />

        <link href="<?php echo base_url(); ?>assets/peserta/css/sweetalert.css" rel="stylesheet" />-->





        <!--     Fonts and icons     -->

        <!-- <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->

        <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">

        <!-- <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'> -->

        <!-- <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" /> -->



    </head>