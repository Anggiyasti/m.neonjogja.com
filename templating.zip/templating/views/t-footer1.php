<!-- ini START Template Footer -->

        <script type="text/javascript" src="<?=base_url('assets/library/jquery/js/jquery.min.js');?>"></script>
        <!--/ END Template Footer -->
        <script type="text/javascript" src="<?=base_url('assets/library/jquery/js/jquery-migrate.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/library/bootstrap/js/bootstrap.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/library/core/js/core.min.js');?>"></script>
        <!--/ Library script -->

        <!-- App and page level script -->
        <script type="text/javascript" src="<?=base_url('assets/plugins/sparkline/js/jquery.sparkline.min.js');?>"></script><!-- will be use globaly as a summary on sidebar menu -->
        <script type="text/javascript" src="<?=base_url('assets/javascript/app.min.js');?>"></script>
        
        <!-- ini footer -->
        <script type="text/javascript" src="<?=base_url('assets/plugins/magnific/js/jquery.magnific-popup.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/plugins/shuffle/js/jquery.shuffle.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/plugins/owl/js/owl.carousel.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/javascript/pages/frontend/portfolio.js');?>"></script>

        <!-- slider -->
        <script type="text/javascript" src="<?=base_url('assets/plugins/layerslider/js/greensock.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/plugins/layerslider/js/transitions.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/plugins/layerslider/js/layerslider.min.js');?>"></script>
        <!-- slider -->
        <script type="text/javascript" src="<?=base_url('assets/plugins/owl/js/owl.carousel.min.js');?>"></script>
        <script type="text/javascript" src="<?=base_url('assets/javascript/pages/frontend/home.js');?>"></script>
</body>