<!-- Footer -->
          <footer class="page-footer primary-color m-t-20">
          <div class="container">
            <div class="row">
              <div class="col s12">
                <p class="center-align grey-text text-lighten-4">You can use rows and columns here to organize your footer content.</p>
                <div class="center-align">
                  <i class="ion-social-facebook m-10 white-text"></i>
                  <i class="ion-social-twitter m-10 white-text"></i>
                  <i class="ion-social-pinterest m-10 white-text"></i>
                  <i class="ion-social-dribbble m-10 white-text"></i>
                </div>
              </div>
            </div>
          </div>
          <div class="footer-copyright red darken-1">
            <div class="container">
            2016 Codnauts
            <a class="grey-text text-lighten-4 right" href="#!">Privacy Policy</a>
            </div>
          </div>
        </footer>