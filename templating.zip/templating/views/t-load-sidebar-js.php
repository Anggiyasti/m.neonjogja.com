<script type="text/javascript" src="<?=base_url('javascript/app.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('plugins/flot/jquery.flot.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('plugins/flot/jquery.flot.categories.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('plugins/flot/jquery.flot.tooltip.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('plugins/flot/jquery.flot.resize.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('plugins/flot/jquery.flot.spline.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('plugins/selectize/js/selectize.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('javascript/pages/dashboard.js');?>"></script>