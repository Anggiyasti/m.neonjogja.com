<div class="page-title" style="background:#2b3036">
	<div class="grid-row">
		<h1>{judul_header}</h1>
	</div>
</div>