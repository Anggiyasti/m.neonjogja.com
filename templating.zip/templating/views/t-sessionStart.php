<?php

$sess_array = array();
$sess_array = array(
    'id' => null,
    'USERNAME' => null,
    'HAKAKSES' => null,
    'AKTIVASI' => null,
    'id_guru' => null,
);
$this->session->set_userdata($sess_array);
?>