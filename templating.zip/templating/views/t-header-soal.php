<html class="frontend">



    <!-- START Head -->

    <head>

        <title>Workout</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="user-scalable=no, initial-scale=1.0, maximum-scale=1.0 minimal-ui" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black">

       

   



        <link rel="shortcut icon" href="<?= base_url('assetsnew/back/img/favicon.png') ?>">

        <link rel="stylesheet" href="<?= base_url('assetsnew/library/bootstrap/css/bootstrap.min.css'); ?>">

       



        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assetsnew/images/logofix.png')?>">

        

        <script src="<?= base_url('assetsnew/sal/sweetalert-dev.js');?>"></script>
        <link rel="stylesheet" href="<?= base_url('assetsnew/sal/sweetalert.css');?>">
                <!-- END STYLESHEETS -->



        <!-- START JAVASCRIPT SECTION - Load only modernizr script here -->

        

        <script type="text/javascript" src="<?= base_url('assetsnew/js/jquery.min.js') ?>"></script>
        



        <link rel="stylesheet" href="<?= base_url('assetsnew/plugins/layerslider/css/layerslider.min.css'); ?>">


    </head>





<!--     </head> -->