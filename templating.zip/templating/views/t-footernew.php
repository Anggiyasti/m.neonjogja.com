	<script src="js/jquery-2.1.0.min.js"></script>
	<script src="js/jquery.swipebox.min.js"></script>   
    <script src="js/materialize.min.js"></script> 
    <script src="js/swiper.min.js"></script>  
    <script src="js/jquery.mixitup.min.js"></script>
    <script src="js/masonry.min.js"></script>
    <script src="js/chart.min.js"></script>
    <script src="js/functions.js"></script>