<!-- ini START Template Footer -->







<script type="text/javascript" src="<?= base_url('assetsnew/library/jquery/jquery.min.js'); ?>"></script>



<script type="text/javascript" src="<?= base_url('assetsnew/library/bootstrap/js/bootstrap.min.js'); ?>"></script>



<script type="text/javascript" src="<?= base_url('assetsnew/library/core/js/core.min.js'); ?>"></script>



<!--/ Library script -->







<!-- App and page level script -->



<!-- ini footer -->


<script type="text/javascript" src="<?= base_url('assetsnew/plugins/owl/js/owl.carousel.min.js'); ?>"></script>



<script type="text/javascript" src="<?= base_url('assetsnew/javascript/pages/frontend/home.js'); ?>"></script>

<!-- Start Math jax --> 
<script type="text/x-mathjax-config"> 
    MathJax.Hub.Config({ 
    tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]} 
    }); 
</script> 
<script type="text/javascript" async 
        src="<?= base_url('assetsnew/plugins/MathJax-master/MathJax.js?config=TeX-MML-AM_HTMLorMML') ?>">
</script> 
<!-- end Math jax -->

</body>